#define CL_USE_DEPRECATED_OPENCL_1_2_APIS
#define __CL_ENABLE_EXCEPTIONS

#include <iostream>
#include <vector>
#include <fstream>

#ifdef __APPLE__
#include <OpenCL/cl.hpp>
#else
#include <CL/cl.hpp>
#endif

#include "Utils.h"

std::vector<int> A; //create a new vector that we'll put the temp data in

int main(int argc, char **argv) {
	//Part 1 - handle command line options such as device selection, verbosity, etc.
	int platform_id = 0;
	int device_id = 0;

	//detect any potential exceptions
	try {

		//Part 2 - host operations
		//2.1 Select computing devices
		cl::Context context = GetContext(platform_id, device_id);

		//display the selected device
		std::cout << "Runinng on " << GetPlatformName(platform_id) << ", " << GetDeviceName(platform_id, device_id) << std::endl;

		//create a queue to which we will push commands for the device
		cl::CommandQueue queue(context, CL_QUEUE_PROFILING_ENABLE);

		//2.2 Load & build the device code
		cl::Program::Sources sources;

		AddSources(sources, "my_kernels_3.cl"); //location of the kernal data

		cl::Program program(context, sources); //adds source location info to the program

		FILE *textfile = fopen("C:/Users/Harry/Desktop/Tutorial 3/temp_lincolnshire.txt", "r"); //location of the text files we'll be analysing

		while (!feof(textfile)) { //while not at the end of the file (textfile)
			float temp; //temporary data storage
			fscanf(textfile, "%*s %*s %*s %*s %*s %f", &temp); //Ignore everything but the last value as we're only interested in the temperature (save memory)
			//fscanf reads the file textfile, anything with a * gets ignored. in this case only the 6th element is not ignored, which is then mapped to the temp variable
			A.push_back(temp*10); //adds temp to the end of the A vector, the *10 is to make non-whole numbers into numbers that an int can read. things are /10 later in the code and placed in floats
		}
		fclose(textfile); //once read the file isnt needed as all data is in the A vector

		//build and debug the kernel code
		try {
			program.build();
		}
		catch (const cl::Error& err) {
			std::cout << "Build Status: " << program.getBuildInfo<CL_PROGRAM_BUILD_STATUS>(context.getInfo<CL_CONTEXT_DEVICES>()[0]) << std::endl;
			std::cout << "Build Options:\t" << program.getBuildInfo<CL_PROGRAM_BUILD_OPTIONS>(context.getInfo<CL_CONTEXT_DEVICES>()[0]) << std::endl;
			std::cout << "Build Log:\t " << program.getBuildInfo<CL_PROGRAM_BUILD_LOG>(context.getInfo<CL_CONTEXT_DEVICES>()[0]) << std::endl;
			throw err;
		}

		cl::Event sum_event; //these events are used to time program funcitons
		cl::Event min_event; //there is one for each kernal calculation 
		cl::Event max_event;
		cl::Event deviation_event; //and two for deviation because i use two kernal functions
		cl::Event deviation_event2; //to find the standard deviation of the data. they get combined to find total time of the process

		//Part 3 - memory allocation
		//host - input

		//the following part adjusts the length of the input vector so it can be run for a specific workgroup size
		//if the total input length is divisible by the workgroup size this makes the code more efficient
		size_t local_size = 256;

		size_t padding_size = A.size() % local_size;//padding is used when the local size isnt an exact fit to the data length

		//if the input vector is not a multiple of the local_size
		//insert additional neutral elements (0 for addition) so that the total will not be affected
		if (padding_size) {
			//create an extra vector with neutral values
			std::vector<int> A_ext(local_size-padding_size, 0);
			//append that extra vector to our input
			A.insert(A.end(), A_ext.begin(), A_ext.end());
		}

		size_t input_elements = A.size();//number of input elements
		size_t input_size = A.size()*sizeof(int);//size in bytes
		size_t nr_groups = input_elements / local_size; //works out how many workgroups there are by dividing items by workgroup size

		//host - output
		std::vector<int> B(input_elements); //make a new 
		std::vector<float> C(input_elements);
		std::vector<int> D(1);
		size_t output_size = B.size()*sizeof(int);//size in bytes

		//device - buffers
		cl::Buffer buffer_A(context, CL_MEM_READ_ONLY, input_size); //buffer for A is never edited so make it read only
		cl::Buffer buffer_B(context, CL_MEM_READ_WRITE, output_size); //buffer for b is size of expected output
		cl::Buffer buffer_C(context, CL_MEM_READ_WRITE, input_size); //buffer c is used with standard dev, and is used as an input for that 
		cl::Buffer buffer_D(context, CL_MEM_READ_WRITE, 1 * sizeof(int)); //d is only ever having a single unsigned int value so give that much room in memory

		//Part 4 - device operations
		
		//4.1 copy array A to and initialise other arrays on device memory
		queue.enqueueWriteBuffer(buffer_A, CL_TRUE, 0, input_size, &A[0]);//vector A is stored in device memory
		queue.enqueueFillBuffer(buffer_B, 0, 0, output_size);//empty buffer of size output_size for B in memory
		queue.enqueueFillBuffer(buffer_C, 0, 0, input_size);//empty buffer of size input_size for C in memory				
		queue.enqueueFillBuffer(buffer_D, 0, 0, 1 * sizeof(int));//space for a single int is reserved in memory

		//4.2 Setup and execute all kernels (i.e. device code)
		cl::Kernel reduce_sum = cl::Kernel(program, "reduce_sum"); //run kernal reduce sum
		reduce_sum.setArg(0, buffer_A);
		reduce_sum.setArg(1, buffer_B);
		reduce_sum.setArg(2, cl::Local(local_size * sizeof(int))); //third argument creates local storage thats the size of local_size multipled by the size of an int

		cl::Kernel reduce_min = cl::Kernel(program, "reduce_min");//run kernal reduce min
		reduce_min.setArg(0, buffer_A);
		reduce_min.setArg(1, buffer_B);
		reduce_min.setArg(2, cl::Local(local_size * sizeof(int)));

		cl::Kernel reduce_max = cl::Kernel(program, "reduce_max");//run kernal reduce max
		reduce_max.setArg(0, buffer_A);
		reduce_max.setArg(1, buffer_B);
		reduce_max.setArg(2, cl::Local(local_size * sizeof(int)));
		
		//call all kernels in a sequence
		queue.enqueueNDRangeKernel(reduce_sum, cl::NullRange, cl::NDRange(input_elements), cl::NDRange(local_size), NULL, &sum_event);// the & parts are where the timing events track time
		queue.enqueueNDRangeKernel(reduce_min, cl::NullRange, cl::NDRange(input_elements), cl::NDRange(local_size), NULL, &min_event);
		queue.enqueueNDRangeKernel(reduce_max, cl::NullRange, cl::NDRange(input_elements), cl::NDRange(local_size), NULL, &max_event);

		//4.3 Copy the result from device to host
		queue.enqueueReadBuffer(buffer_B, CL_TRUE, 0, output_size, &B[0]); // copy buffer b into vector b

		int size = A.size(); //
		float mean = B[0] / A.size();

		cl::Kernel std_var = cl::Kernel(program, "std_var");//standard dev is different to the other maths, i could only get it to run over two functions 
		std_var.setArg(0, buffer_A); //
		std_var.setArg(1, buffer_C);
		std_var.setArg(2, mean);
		std_var.setArg(3, size);
		std_var.setArg(4, cl::Local(local_size * sizeof(float)));
		queue.enqueueNDRangeKernel(std_var, cl::NullRange, cl::NDRange(input_elements), cl::NDRange(local_size), NULL, &deviation_event); // Call kernel in sequence
		queue.enqueueReadBuffer(buffer_C, CL_TRUE, 0, input_size, &C[0]); // copy buffer c into vector c

		cl::Kernel std_sum = cl::Kernel(program, "std_sum");	// Define kernel, call kernel from .cl file
		std_sum.setArg(0, buffer_C);	// Pass arguement/buffer to kernel
		std_sum.setArg(1, buffer_D);	// ^^ ^^ ^^
		std_sum.setArg(2, cl::Local(local_size * sizeof(int)));	// Local memory instantiated to local_size(bytes)
		queue.enqueueNDRangeKernel(std_sum, cl::NullRange, cl::NDRange(input_elements), cl::NDRange(local_size), NULL, &deviation_event2);  // Call kernel in sequence
		queue.enqueueReadBuffer(buffer_D, CL_TRUE, 0, 1 * sizeof(int), &D[0]); // copy buffer c into vector c

		float std_mean = ((float)D[0] /10)  / C.size();
		float std_sqrt = sqrt(std_mean);

		int Sumexecution = sum_event.getProfilingInfo<CL_PROFILING_COMMAND_END>() - sum_event.getProfilingInfo<CL_PROFILING_COMMAND_START>();//these all stop the events
		int Minexecution = min_event.getProfilingInfo<CL_PROFILING_COMMAND_END>() - min_event.getProfilingInfo<CL_PROFILING_COMMAND_START>();
		int Maxexecution = max_event.getProfilingInfo<CL_PROFILING_COMMAND_END>() - max_event.getProfilingInfo<CL_PROFILING_COMMAND_START>();
		int Dev1execution = deviation_event.getProfilingInfo<CL_PROFILING_COMMAND_END>() - deviation_event.getProfilingInfo<CL_PROFILING_COMMAND_START>();
		int Dev2execution = deviation_event2.getProfilingInfo<CL_PROFILING_COMMAND_END>() - deviation_event2.getProfilingInfo<CL_PROFILING_COMMAND_START>();
		int Totalexecution = Sumexecution + Minexecution + Maxexecution + Dev1execution + Dev2execution; //gives total runtime of the program

		//std::cout << "A = " << A << std::endl;
		std::cout << "--Values--"  << std::endl;
		std::cout << "Sum = " << B[0] / 10 << std::endl; //divide by 10 because earlier i *10 to make 2.5 = 25 etc and get more accurate data without using float arrays
		std::cout << "Min = " << B[1] / 10 << std::endl;
		std::cout << "Max = " << B[2] / 10 << std::endl;
		std::cout << "Mean = " << mean / 10 << std::endl;
		std::cout << "Deviation = " << std_sqrt << std::endl;

		std::cout << "--Times (ns)--" << std::endl;
		std::cout << "Sum time = " << Sumexecution << std::endl;
		std::cout << "Min time = " << Minexecution << std::endl;
		std::cout << "Max time = " << Maxexecution << std::endl;
		std::cout << "Deviation time = " << Dev1execution + Dev2execution << std::endl;
		std::cout << "Total time = " << Totalexecution << std::endl;
		}
	catch (cl::Error err) {
		std::cerr << "ERROR: " << err.what() << ", " << getErrorString(err.err()) << std::endl;
	}

	return 0;
}
